package com.example.android.booklisting;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class BookActivity extends AppCompatActivity {

    public static final String LOG_TAG = BookActivity.class.getName();

    ListView bookListView;
    ArrayList<Book> books = new ArrayList<>();
    BookAdapter mAdapter;
    SearchView searchView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book);

        if(savedInstanceState == null || !savedInstanceState.containsKey("BOOK_LIST")) {
            bookListView = (ListView) findViewById(R.id.list);
        }
        else {
            books = savedInstanceState.getParcelableArrayList("BOOK_LIST");
        }
        // Find a reference to the {@link ListView} in the layout
       //bookListView = (ListView) findViewById(R.id.list);
    }

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putParcelableArrayList("BOOK_LIST", books);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this add items to the action bar if it is present.
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_search_view, menu);
        MenuItem item = menu.findItem(R.id.menuSearch);
        searchView = (SearchView)item.getActionView();

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                Log.d(LOG_TAG, "setOnQueryTextListener: " + query);
                ConnectivityManager connMgr = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
                NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
                if (networkInfo != null && networkInfo.isConnected()) {
                    Log.d(LOG_TAG, "Network connected...");
                    BookAsyncTask task = new BookAsyncTask();
                    String[] queryParam = {query};
                    task.execute(queryParam);
                } else {
                    Log.d(LOG_TAG, "Network offline");
                    showToast(getString(R.string.network_unavailable_message));
                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });

        return super.onCreateOptionsMenu(menu);
    }

    //A method to display error messages
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private class BookAsyncTask extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... params) {
            Log.d(LOG_TAG, "doInBackground: " + params[0]);

            try {
                makeHttpRequest(params[0]);
            } catch (IOException e) {
                Log.d(LOG_TAG, "Error on Http Request");
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void v) {

            super.onPostExecute(v);
            updateBookList();
        }

        private void updateBookList() {
            mAdapter = new BookAdapter(getBaseContext(), books);
            bookListView.setAdapter(mAdapter);
            mAdapter.notifyDataSetChanged();
        }

        //Make an HTTP request to the given URL and return a String as the response.
        private void makeHttpRequest(String params) throws IOException {
            Log.d(LOG_TAG, "makeHttpRequest: " + params);
            InputStream inputStream = null;

            try {
                String encodedQuery = URLEncoder.encode(params, "utf-8");
                URL url = new URL(getResources().getString(R.string.http_query_address) + encodedQuery);

                Log.d(LOG_TAG, "url: " + url.toString());
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setReadTimeout(getResources().getInteger(R.integer.http_read_timeout));
                httpURLConnection.setConnectTimeout(getResources().getInteger(R.integer.http_connect_timeout));
                httpURLConnection.setRequestMethod("GET");
                httpURLConnection.connect();

                int response = httpURLConnection.getResponseCode();
                Log.d(LOG_TAG, "Response code is: " + response);

                switch (response) {
                    case HttpURLConnection.HTTP_OK:
                        inputStream = httpURLConnection.getInputStream();
                        String stringResponse = readIt(inputStream);
                        parseJson(stringResponse);
                        break;
                    case HttpURLConnection.HTTP_NOT_FOUND:
                        showToast(getString(R.string.http_url_not_found_message));
                        break;
                    default:
                        showToast(getString(R.string.http_generic_error_message));
                        break;
                }
            } finally {
                if (inputStream != null) {
                    inputStream.close();
                }
            }
        }

        public void parseJson(String bookJSON) {
            try {
                books.clear();

                // Create a JSONObject from the JSON response string
                JSONObject jsonObject = new JSONObject(bookJSON);

                // Extract the JSONArray associated with the key called "items",
                // which represents a list of features (or books).
                JSONArray resultArray = jsonObject.getJSONArray(getString(R.string.json_items_key));

                // For each book in the bookArray, create a Book object
                for(int i = 0; i < resultArray.length(); i++) {
                    //ArrayList<String> authorList = new ArrayList<>();
                    //Book book = new Book();

                    // Get a single book at position i within the list of books
                    JSONObject volumeInfo = resultArray.getJSONObject(i);

                    // For a given Book, extract the JSONObject associated with the
                    // key called "volumeInfo", which represents a list of all properties
                    // for that book.
                    JSONObject bookVolumeInfo = volumeInfo.getJSONObject(getString(R.string.json_volume_info_key));

                    // Extract the value for the key called "title"
                    String bookTitle = bookVolumeInfo.getString(getString(R.string.json_title_key));

                    //Extract the value for the key called "authors"
                    //Some books doesn't have authors, implement try catch method to prevent null value.
                    JSONArray bookAuthors = null;
                    try {
                        bookAuthors = bookVolumeInfo.getJSONArray(getString(R.string.json_authors_key));
                    } catch (JSONException ignored) {
                    }
                    //Set the authors to Unknown if there is no authors returned
                    String hasBookAuthors = "";
                    if (bookAuthors == null) {
                        hasBookAuthors = "Unknown";
                    } else {
                        //Format the authors value returned as "author1, author2, and author3"
                        int count = bookAuthors.length();
                        for (int c = 0; c < count; c++) {
                            String author = bookAuthors.getString(c);
                            if (hasBookAuthors.isEmpty()) {
                                hasBookAuthors = author;
                            } else if (c == count - 1) {
                                hasBookAuthors = hasBookAuthors + " and " + author;
                            } else {
                                hasBookAuthors = hasBookAuthors + ", " + author;
                            }
                        }
                    }

                    //Image Links
                    JSONObject bookImageLinks = null;
                    try {
                        bookImageLinks = bookVolumeInfo.getJSONObject("imageLinks");
                    } catch (JSONException ignored) {
                    }
                    // Convert the Image Links to String
                    String bookSmallThumbnail = "";
                    if ( bookImageLinks == null){
                        bookSmallThumbnail = "null";
                    }else{
                        bookSmallThumbnail = bookImageLinks.getString("smallThumbnail");
                    }

                    // Create a new Book object with the bookTitle, hasBookAuthors, bookImageLinks
                    Book book = new Book(bookTitle, hasBookAuthors, bookSmallThumbnail);

                    // Add the new Book to the list of books.
                    books.add(book);
                }

            } catch (JSONException e) {
                Log.d(LOG_TAG, "JSONException");
                e.printStackTrace();
            }
        }

        public String readIt(InputStream stream) throws IOException {
            StringBuilder builder = new StringBuilder();
            BufferedReader responseReader = new BufferedReader(new InputStreamReader(stream));
            String line = responseReader.readLine();

            while (line != null){
                builder.append(line);
                line = responseReader.readLine();
            }

            return builder.toString();
        }
    }
}