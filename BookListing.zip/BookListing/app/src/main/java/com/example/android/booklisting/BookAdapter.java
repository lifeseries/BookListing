package com.example.android.booklisting;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;


public class BookAdapter extends ArrayAdapter<Book> {
    private final Context mContext;
    ArrayList<Book> books;

    public BookAdapter(Context context, ArrayList<Book> books) {
        super(context, 0, books);
        mContext = context;
        this.books = books;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        // Check if the existing view is being reused, otherwise inflate the view
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.activity_list_item, parent, false);
        }

        // Get the Book object located at this position in the list
        Book currentBook = getItem(position);

        // Find the TextView in the activity_list_item.xml layout with the ID book title
        TextView bookTitleView = (TextView) listItemView.findViewById(R.id.book_title);
        // Display the Title of the current Book in that TextView
        bookTitleView.setText(currentBook.getTitle());

        // Find the TextView in the activity_list_item.xml layout with the ID book authors
        TextView bookAuthorsView = (TextView) listItemView.findViewById(R.id.book_author);
        // Display the authors of the current Book in that TextView
        bookAuthorsView.setText("by " + currentBook.getAuthors());

        // Find the TextView in the activity_list_item.xml layout with the ID book image
        ImageView bookImageView = (ImageView) listItemView.findViewById(R.id.book_image);
        // Display the image of the current Book in that TextView
        Picasso.with(mContext).load(currentBook.getThumbnailLink()).resize(192, 252) .placeholder(R.drawable.thumbnail_placeholder)
                .into(bookImageView);

        // Return the whole list item layout (containing 2 TextViews)
        // so that it can be shown in the ListView
        return listItemView;
    }
}

