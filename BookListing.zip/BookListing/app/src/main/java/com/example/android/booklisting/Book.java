package com.example.android.booklisting;


import android.os.Parcel;
import android.os.Parcelable;

public class Book implements Parcelable{

    //Title of the books
    String mTitle;
    // Authors of the books
    String mAuthors;
    //Thumbnail of the books
    String mThumbnailLink;

    public Book(Parcel in) {
        mTitle = in.readString();
        mAuthors = in.readString();
        mThumbnailLink = in.readString();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel out, int flags) {
        out.writeString(mTitle);
        out.writeString(mAuthors);
        out.writeString(mTitle);

    }
    public static final Parcelable.Creator<Book> CREATOR = new Parcelable.Creator<Book>() {

        @Override
        public Book createFromParcel(Parcel source) {
            return new Book(source);
        }

        @Override
        public Book[] newArray(int size) {
            return new Book[size];
        }
    };


    //Constructor passing three arguments
    public Book(String title, String authors, String thumbnailLink){
        mTitle = title;
        mAuthors = authors;
        mThumbnailLink = thumbnailLink;
    }


    //Return the title of the books
    public String getTitle(){
        return mTitle;
    }

    //Return the authors of the books
    public String getAuthors(){
        return mAuthors;
    }

    //Return the thumbnail of the books
    public String getThumbnailLink(){
        return mThumbnailLink;
    }

}
